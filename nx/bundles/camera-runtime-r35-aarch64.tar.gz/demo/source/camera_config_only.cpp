#include <cstdio>
#include "hb_vin_interface.h"

// Configure the serializer, deserializer, and sensor from the migrated JSON
// without opening a V4L2 capture device.  The vendor jpegenc_demo opens
// /dev/video* and then loops forever, which makes forced shutdown leave the
// R35 driver in EBUSY state.
int main(int argc, char **argv)
{
    const char *config = argc > 1 ? argv[1] : "./cfg/hb_j5dev.json";
    const int ret = hb_vin_init(0, config);
    if (ret < 0) {
        std::fprintf(stderr, "camera configuration failed: hb_vin_init=%d\n", ret);
        return 1;
    }

    std::printf("camera configuration completed (no V4L2 capture opened)\n");
    return 0;
}
