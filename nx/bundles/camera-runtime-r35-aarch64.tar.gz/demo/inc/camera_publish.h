#pragma once
#include <chrono>
#include <memory>
#include <string>
#include <unistd.h>
#include <bits/stdc++.h>

#ifdef SUPPORT_ROS2
#include "rclcpp/rclcpp.hpp"
#include "sensor_msgs/msg/image.hpp"
#include "sensor_msgs/msg/compressed_image.hpp"

class CCameraPublisher : public rclcpp::Node
{
public:
    /**
     * @brief CCameraPublisher 构造函数
     *
     * 使用给定的相机配置和发布器创建 CCameraPublisher 对象。
     *
     * @param camCfg 相机配置
     * @param publisher 发布器指针
     */
    CCameraPublisher(std::string name);

    /**
     * @brief CCameraPublisher 类的析构函数
     *
     * CCameraPublisher 类的析构函数，用于释放资源。
     */
    ~CCameraPublisher();

    bool Publisher(struct timespec stTime, unsigned char *pData, int nDatalen);

private:
    char m_szTopic[128];
    rclcpp::Publisher<sensor_msgs::msg::CompressedImage>::SharedPtr m_Publisher;
};
#endif