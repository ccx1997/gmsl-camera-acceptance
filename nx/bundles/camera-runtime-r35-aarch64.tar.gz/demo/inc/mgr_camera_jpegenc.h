#pragma once
#include <queue>
#include <bits/stdc++.h>
#include "jpeg_encode_api.h"
#include "camera_type.h"
#include "vin_log.h"
#ifdef SUPPORT_ROS2
#include "camera_publish.h"
#endif
using namespace std;
	

class CMgrCameraJpegEnc
{
public:
	CMgrCameraJpegEnc(int dwChan, int dwWidth, int dwHeight, int dwQuality);
	~CMgrCameraJpegEnc();
	virtual bool Init();
	virtual bool Release();
	bool Save(int nChan,struct timespec stTime,int nWidth,int nHeight,unsigned char *pData,int nDatalen);
	friend void CALLBACK JpegEncCallBack(unsigned char *data,int datalen,void *userdata);
protected:
	bool createHandle();
	bool destroyHandle();
private:
	int					m_dwChan;
	int					m_dwWidth;
	int					m_dwHeight;
	int 				m_dwQuality;
	void*				m_pEncHandle;
	queue<string> 		m_qFileName;
	mutex               m_mutex;
	unsigned char*      m_pYuv;
#ifdef SUPPORT_ROS2
    std::shared_ptr<CCameraPublisher> m_pRosPublisher;
#endif
};
